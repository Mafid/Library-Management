from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.contrib.auth import get_user_model
from datetime import timedelta, date
from django.utils import timezone

# Create your models here.
class Contact(models.Model):
    name = models.CharField(max_length=122)
    email = models.CharField(max_length=122)
    phone = models.CharField(max_length=12)
    desc =  models.TextField()
    date = models.DateField()

    def __str__(self):
        return self.name


# Login Functionality
class CustomUserManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)  # Set the password securely
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, password, **extra_fields)



# Register Forms
class User(AbstractBaseUser, PermissionsMixin):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=255)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = CustomUserManager() 

    # Fix reverse accessor clashes by adding related_name to 'groups' and 'user_permissions'
    groups = models.ManyToManyField(
        'auth.Group',
        related_name='custom_user_set',  
        blank=True
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='custom_user_permissions_set', 
        blank=True
    )

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


# Books Add
# User = get_user_model()
class Book(models.Model):

    STATUS_CHOICES = [
        ('AVAILABLE', 'Available'),
        ('BORROWED', 'Borrowed'),
    ]
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    description = models.TextField()
    published_date = models.DateField()
    cover_image = models.ImageField(upload_to='book_covers/', blank=True, null=True)
    status = models.CharField(
        max_length=9,
        choices=STATUS_CHOICES,
        default='AVAILABLE'
    )   
    def __str__(self):
        return f"{self.title} ({self.get_status_display()})"
   

#trial





class BorrowBook(models.Model):
    user_name = models.CharField(max_length=255)     # “User Name” from your form
    library_id = models.CharField(max_length=100)    # “Library ID” from your form
    book_title = models.CharField(max_length=255)    # For reference, though better is a FK
    author = models.CharField(max_length=255)        # For reference, though better is a FK
    issue_date = models.DateField(default=timezone.now)
    
    # (Optional) Link directly to the Book model if desired:
    # book = models.ForeignKey(Book, on_delete=models.CASCADE, null=True, blank=True)
    
    def save(self, *args, **kwargs):
        """
        Overriding save() to update the book’s status to BORROWED
        whenever a BorrowedBook record is created/updated.
        """
        super().save(*args, **kwargs)

        # fetch that book and update its status:
        try:

            book_obj = Book.objects.get(title=self.book_title, author=self.author)
            book_obj.status = 'BORROWED'
            book_obj.save()
        except Book.DoesNotExist:
            pass 

    def __str__(self):
        return f"{self.user_name} borrowed {self.book_title}"
