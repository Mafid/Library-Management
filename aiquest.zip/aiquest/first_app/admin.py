from django.contrib import admin
from first_app.models import Contact , User , Book , BorrowBook
# Register your models here.

admin.site.register(Contact)
admin.site.register(User)
admin.site.register(Book)
admin.site.register(BorrowBook)
