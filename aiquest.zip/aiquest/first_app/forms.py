from django import forms
from .models import BorrowBook

class BorrowBookForm(forms.ModelForm):
    class Meta:
        model = BorrowBook
        fields = ['user_name', 'library_id', 'book_title', 'author', 'issue_date']
        
        # If you want a nice date widget:
        widgets = {
            'issue_date': forms.DateInput(attrs={'type': 'date'}),
        }

