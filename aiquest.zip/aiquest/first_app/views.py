from django.shortcuts import render, redirect , get_object_or_404
from datetime import datetime
from first_app.models import Contact
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, logout , login
from .models import User
from django.contrib.auth.hashers import check_password , make_password
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from .models import Book , BorrowBook
from .forms import BorrowBookForm
from django.utils import timezone
from datetime import timedelta
from django.contrib.auth import get_user_model


def index(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Authenticate using the custom backend
        user = authenticate(request, username=email, password=password, backend='first_app.backends.EmailAuthBackend')

        if user is not None:
            # Log the user in
            login(request, user)
            return redirect('dashboard')
        else:
            return render(request, 'index.html', {'error': 'Invalid credentials. Please try again.'})

    return render(request, 'index.html')




def signup(request):
    if request.method == 'POST':
        # Get the data from the form
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password_repeat = request.POST['password_repeat']

        # Check if passwords match
        if password != password_repeat:
            return render(request, 'sign_up.html', {'error': 'Passwords do not match.'})
        hashed_password = make_password(password)
        user = User.objects.create_user(first_name=first_name, last_name=last_name, email=email, password=hashed_password)
        user.first_name = first_name
        user.last_name = last_name
        user.save()
        return redirect('index') 
    
    return render(request, 'sign_up.html')




def home(request):
    return render(request,'home.html')

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date = datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent!')
    return render(request,'contact.html')



def b_library(request):
    return render(request, 'baiust_library.html')

def lib_policy(request):
    return render(request, 'lib_policy.html')

def member(request):
    return render(request, 'member.html')

def facility(request):
    return render(request, 'facility.html')

def lending(request):
    return render(request, 'lending.html')

def con(request):
    return render(request, 'con.html')


def dashboard(request):
    return render(request, 'dashboard.html', {'user': request.user})

def borrow_book(request):
    return render(request, 'borrow_book.html')

def renew_book(request):
    return render(request, 'renew_book.html')


def search_books(request):
    query = request.GET.get('q', '')  # Get the search term from the query string
    results = []
    message = ""

    if query:
        # Filter books whose name contains the query (case-insensitive)
        results = Book.objects.filter(title__icontains=query)
        if not results:
            message = "No book found"

    context = {
        'results': results,
        'query': query,
        'message': message,
    }
    return render(request, 'search_results.html', context)




# trial 
from .forms import BorrowBookForm

def borrow_book(request):
    if request.method == 'POST':
        form = BorrowBookForm(request.POST)
        if form.is_valid():
            form.save()  
            # The save() method will also set the book’s status to BORROWED
            return redirect('dashboard')  # or wherever you want to go
    else:
        form = BorrowBookForm()
    
    return render(request, 'borrow_book.html', {'form': form})
